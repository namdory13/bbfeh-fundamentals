set terminal png size 800,400
set output 'kernel.png'

set title 'BBFEH Kernel'
set xlabel 'Delay'
set ylabel 'Amplitude'

plot '-' using 1:2 with impulses linewidth 2 title 'Kernel'
-350 -0.1
-250  0.1
0      1
250    0.1
350   -0.1
e
