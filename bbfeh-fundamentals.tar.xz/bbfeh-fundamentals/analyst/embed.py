#!/usr/bin/env python3

import soundfile as sf
import numpy as np

msg = open("message.txt").read().strip()

x, sr = sf.read("audio/cover.wav")

alpha = 0.1
delay0 = 250
delay1 = 350
L = 4096

y = np.copy(x)

for i, bit in enumerate(msg):

    start = i * L
    end = start + L

    if end >= len(x):
        break

    seg = x[start:end]

    d = delay0 if bit == '0' else delay1

    echo = np.zeros_like(seg)

    echo[d:] = seg[:-d] * alpha

    y[start:end] += echo

    print(f"Embedding bit {bit} into segment {i}")

sf.write("stego.wav", y, sr)

print("\n[+] stego.wav created")
