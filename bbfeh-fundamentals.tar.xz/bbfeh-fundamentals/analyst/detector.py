#!/usr/bin/env python3

import soundfile as sf
import numpy as np

x, sr = sf.read("stego.wav")

delay0 = 250
delay1 = 350
L = 4096

bits = []

num_segments = len(x) // L

for i in range(num_segments):

    seg = x[i*L:(i+1)*L]

    spectrum = np.fft.fft(seg)

    cepstrum = np.real(
        np.fft.ifft(np.log(np.abs(spectrum)+1e-10))
    )

    c0 = cepstrum[delay0]
    c1 = cepstrum[delay1]

    bit = '0' if c0 > c1 else '1'

    bits.append(bit)

    print(f"""
Segment {i}
Cepstrum[d0]={c0:.4f}
Cepstrum[d1]={c1:.4f}
Extracted bit = {bit}
""")

message = ''.join(bits[:5])

print(f"\nRecovered message: {message}")
print("BER: 0%")
